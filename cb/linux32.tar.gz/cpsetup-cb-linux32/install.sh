#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

run_privileged() {
    if [ "$(id -u)" -eq 0 ]; then
        "$@"
    elif command -v sudo >/dev/null 2>&1; then
        sudo "$@"
    else
        echo "[CPSetup] Loi: Can quyen root hoac 'sudo' de cai dat." >&2
        exit 1
    fi
}

echo "[CPSetup] Dang kiem tra & cai dat g++, gdb, codeblocks..."
if command -v pacman >/dev/null 2>&1; then
    run_privileged pacman -Sy --needed --noconfirm gcc gdb codeblocks
elif command -v dnf >/dev/null 2>&1; then
    run_privileged dnf install -y gcc-c++ gdb codeblocks
elif command -v zypper >/dev/null 2>&1; then
    run_privileged zypper --non-interactive install gcc-c++ gdb codeblocks
elif command -v apt-get >/dev/null 2>&1; then
    run_privileged apt-get update
    run_privileged apt-get install -y g++ gdb codeblocks build-essential
elif command -v apk >/dev/null 2>&1; then
    run_privileged apk add --no-cache g++ gdb codeblocks
else
    echo "[CPSetup] Canh bao: Khong nhan dien duoc trinh quan ly goi. Hay dam bao da cai g++, gdb, codeblocks."
fi

run_privileged mkdir -p /usr/local/bin /usr/local/share/cpsetup-cb
run_privileged cp "$SCRIPT_DIR/usr/bin/cb" /usr/local/bin/cb
run_privileged cp "$SCRIPT_DIR/usr/bin/cpsetup-cb-config" /usr/local/bin/cpsetup-cb-config
run_privileged cp "$SCRIPT_DIR/usr/bin/cpsetup-cb-check" /usr/local/bin/cpsetup-cb-check
run_privileged cp "$SCRIPT_DIR/usr/share/cpsetup-cb/default.conf.template" /usr/local/share/cpsetup-cb/default.conf.template
run_privileged chmod 0755 /usr/local/bin/cb /usr/local/bin/cpsetup-cb-config /usr/local/bin/cpsetup-cb-check

/usr/local/bin/cpsetup-cb-config
echo "[CPSetup] Cai dat hoan tat! Go 'cb' de mo Code::Blocks (tat terminal khong bi tat IDE)."
